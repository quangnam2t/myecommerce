(function(window, document) {
    var Header = {
        Scroll: function(argument) {
            var scrollTop = $(window).scrollTop();
            if ($(window).width() > 1023) {
                if (scrollTop > 0) {
                    $('body').addClass('is-fixed');
                } else {
                    $('body').removeClass('is-fixed');
                }
            } else {
                if (!$(".btn-toggle").hasClass('on')) {
                    if (scrollTop > 0) {
                        $('body').addClass('is-fixed');
                    } else {
                        $('body').removeClass('is-fixed');
                    }
                }
            }
            $(window).scroll(function(event) {
                scrollTop = $(window).scrollTop();
                if ($(window).width() > 1023) {
                    if (scrollTop > 0) {
                        $('body').addClass('is-fixed');
                    } else {
                        $('body').removeClass('is-fixed');
                    }
                } else {
                    if (!$(".btn-toggle").hasClass('on')) {
                        if (scrollTop > 0) {
                            $('body').addClass('is-fixed');
                        } else {
                            $('body').removeClass('is-fixed');
                        }
                    }
                }
            });



            var lastScrollTop = 0;
            $(window).scroll(function(event) {
                if ($(window).width() > 1023) {
                    var st = $(window).scrollTop();
                    var bannerH = $('body').find('.banner').outerHeight();
                    if (st > bannerH) {
                        if (st > lastScrollTop) {
                            $('body').removeClass('scroll-up');
                        } else {
                            $('body').addClass('scroll-up');
                        }
                    } else {
                        $('body').removeClass('scroll-up');
                    }
                } else {
                    if (!$(".btn-toggle").hasClass('on')) {
                        var st = $(window).scrollTop();
                        var bannerH = $('body').find('.banner').outerHeight();
                        if (st > bannerH) {
                            if (st > lastScrollTop) {
                                $('body').removeClass('scroll-up');
                            } else {
                                $('body').addClass('scroll-up');
                            }
                        } else {
                            $('body').removeClass('scroll-up');
                        }
                    }

                }
                lastScrollTop = st;

            });
        },
        toggleButton: function() {
            $(".btn.btn-toggle").on('click', function(event) {
                event.preventDefault();
                var _this = $(this);
                if (_this.hasClass("on")) {

                    _this.removeClass("on");
                    _this.parents("header").find(".nav").removeClass('on');
                    _this.parents("header").find(".logo").removeClass('on');
                } else {
                    _this.addClass("on");
                    _this.parents("header").find(".nav").addClass('on');
                    _this.parents("header").find(".logo").addClass('on');
                }
            });
            $(".nav .is-dropdown>a").on('click', function(event) {

                if ($(window).width() < 1024) {
                    event.preventDefault();
                    var _this = $(this).parent();
                    if (_this.hasClass("on")) {
                        _this.removeClass("on");
                        _this.find('.nav-sub').slideUp(350);
                    } else {
                        _this.addClass("on");
                        _this.find('.nav-sub').slideDown(350);
                    }
                    return false;
                }
            });
        },
        navSub: function(argument) {
            var _ele = $(".nav-main").find('.is-dropdown');
            setTimeout(function function_name(argument) {
                if ($(window).width() > 1023) {
                    $(".nav-main").find('.nav-sub').addClass('on-large');
                } else {
                    $(".nav-main").find('.is-dropdown.is-current').find('.nav-sub').slideDown(350);
                    $(".nav-main").find('.nav-sub').removeClass('on-large');
                }
            }, 200);


            $(window).resize(function(event) {
                setTimeout(function function_name(argument) {
                    if ($(window).width() > 1023) {
                        $(".nav-main").find('.nav-sub').addClass('on-large');
                    } else {
                        $(".nav-main").find('.is-dropdown.is-current').find('.nav-sub').slideDown(350);
                        $(".nav-main").find('.nav-sub').removeClass('on-large');
                    }
                }, 200);
            });


            _ele.each(function(index, el) {
                if ($(window).width() > 1023) {
                    $(this).find('.nav-sub').css('padding-left', $(this).offset().left - 22);
                } else {
                    $(this).find('.nav-sub').css('padding-left', '15.6%');
                }
            });
            $(window).resize(function(event) {
                _ele.each(function(index, el) {
                    if ($(window).width() > 1023) {
                        $(this).find('.nav-sub').css('padding-left', $(this).offset().left - 22);
                    } else {
                        $(this).find('.nav-sub').css('padding-left', '15.6%');
                    }
                });
            });

            $(".nav-main>li").hoverIntent(makeTall, makeShort);

            function makeTall() {
                $(this).addClass('is-hover');
            }

            function makeShort() {
                $(this).removeClass('is-hover');
            }
        },
        tooltip: function(argument) {
            var _ele = $(".contact .mail li");
            _ele.hover(function() {
                _ele.removeClass('on');
                var _this = $(this);
                _this.addClass('on');
            }, function() {
                var _this = $(this);
                _this.removeClass('on');
            });
        },
        Hover: function(argument) {
            var _phone = $("#phone");
            _phone.hover(function() {
                if ($(window).width() > 1023) {
                    var _this = $(this);
                    if (!_this.hasClass("on")) {
                        _this.addClass("on");
                    }
                }
            }, function() {
                if ($(window).width() > 1023) {
                    var _this = $(this);
                    if (_this.hasClass("on")) {
                        _this.removeClass("on");
                    }
                }
            });
            var _newLetter = $("#getnewsletter");
            _newLetter.hover(function() {
                if ($(window).width() > 1023) {
                    var _this = $(this);
                    if (!_this.hasClass("on")) {
                        _this.addClass("on");
                    }
                }
            }, function() {
                if ($(window).width() > 1023) {
                    var _this = $(this);
                    if (_this.hasClass("on")) {
                        _this.removeClass("on");
                    }
                }
            });
        }
    }

    var Slider = {
        initSlider: function(argument) {
            $(".banner-for").on('init', function() {
                $(this).css('visibility', 'visible');
            });
            $(".banner-nav").on('init', function() {
                $(this).css('visibility', 'visible');
            });
            var autoplayVal = false;
            if ($('.banner-for').data('transition-option') == 1) {
                autoplayVal = true;
            }
            var speedVal = $('.banner-for').data('transition-cycle'); //default
            speedVal = speedVal * 1000; //miliseconds
            $('.banner-for').slick({
                slidesToShow: 1,
                slidesToScroll: 1,
                arrows: true,
                dots: false,
                fade: true,
                asNavFor: '.banner-nav',
                prevArrow: '.banner-prev',
                nextArrow: '.banner-next',
                speed: 1000,
                autoplay: autoplayVal,
                autoplaySpeed: speedVal,
            });
            $('.banner-nav').slick({
                slidesToShow: 5,
                slidesToScroll: 1,
                asNavFor: '.banner-for',
                dots: false,
                arrows: false,
                focusOnSelect: true,
                centerMode: true,
                useTransform: true,
                centerPadding: 0,
                cssEase: 'cubic-bezier(0.645, 0.045, 0.355, 1.000)',
                responsive: [{
                    breakpoint: 1280,
                    settings: {
                        slidesToScroll: 1,
                    }
                }, {
                    breakpoint: 1024,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 1,
                        centerPadding: "30px",
                    }
                }, {
                    breakpoint: 768,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                        centerMode: false,
                        variableWidth: true,

                    }
                }],
            });

            $(".js-banner").on('init', function() {
                $(this).css('visibility', 'visible');
            });

            $(".js-banner").slick({
                infinite: true,
                dots: false,
                arrows: true,
                useTransform: true,
                cssEase: 'cubic-bezier(0.645, 0.045, 0.355, 1.000)',
                autoplay: true,
                autoplaySpeed: 7000,
                speed: 1000,
                adaptiveHeight: true,
                prevArrow: '.bannerPage-prev',
                nextArrow: '.bannerPage-next',

            });

            setOffSetTT();

            $(window).resize(function(event) {
                setOffSetTT();
            });

            function setOffSetTT() {
                var _ele = $(".banner-page").find('.js-width'),
                    _ctr = $(".banner-page").find('.ctr');
                if (!$("body").hasClass('page-events')) return false;

                var _oLeft = _ele.offset().left,
                    _oRight = _oLeft + _ele.outerWidth() - _ctr.width();

                if ($(window).width() < 1301) {
                    _oRight = _oRight - 20;
                } else {
                    _oRight = _oRight;
                }

                _ctr.css('left', _oRight);


            }

            setTimeout(function(argument) {
                $(".btn.bannerPage-prev").css('opacity', 1);
                $(".btn.bannerPage-next").css('opacity', 1);
            }, 300);

            $('.js-testimonial').slick({
                infinite: true,
                dots: false,
                arrows: true,
                useTransform: true,
                cssEase: 'cubic-bezier(0.645, 0.045, 0.355, 1.000)',
                autoplay: true,
                autoplaySpeed: 7000,
                speed: 1000,
                adaptiveHeight: true,
                prevArrow: '.testimonial-prev',
                nextArrow: '.testimonial-next',

            });

            setOffSetT();

            $(window).resize(function(event) {
                setOffSetT();
            });

            function setOffSetT() {
                var _ele = $(".list-testimonial").find('.js-width'),
                    _ctr = $(".list-testimonial").find('.ctr');
                if ($(".list-testimonial").find('.text').size() == 0) return false;

                var _oLeft = _ele.offset().left,
                    _oRight = _oLeft + _ele.outerWidth() - _ctr.width();

                if ($(window).width() < 1301) {
                    _oRight = _oRight - 20;
                } else {
                    _oRight = _oRight;
                }

                _ctr.css('left', _oRight);


            }

            setTimeout(function(argument) {
                $(".btn.testimonial-prev").css('opacity', 1);
                $(".btn.testimonial-next").css('opacity', 1);
            }, 300);


            $('.more-event .list').slick({
                infinite: false,
                dots: false,
                arrows: false,
                useTransform: true,
                slidesToShow: 3,
                cssEase: 'cubic-bezier(0.645, 0.045, 0.355, 1.000)',
                responsive: [{
                    breakpoint: 768,
                    settings: {
                        slidesToShow: 1,
                        variableWidth: true,
                        infinite: true,
                    }
                }],
            });

            $('.js-team').slick({
                infinite: true,
                dots: false,
                arrows: true,
                useTransform: true,
                slidesToShow: 3,
                cssEase: 'cubic-bezier(0.645, 0.045, 0.355, 1.000)',
                responsive: [{
                    breakpoint: 768,
                    arrows: false,
                    settings: {
                        slidesToShow: 1,
                        variableWidth: true,
                        infinite: true,
                    }
                }],
                prevArrow: '.team-prev',
                nextArrow: '.team-next',
            });

            $('.image-slider').slick({
                infinite: true,
                dots: false,
                arrows: true,
                useTransform: true,
                cssEase: 'cubic-bezier(0.645, 0.045, 0.355, 1.000)',
                autoplay: true,
                autoplaySpeed: 2000,
                speed: 1500,
                prevArrow: '.images-slider-prev',
                nextArrow: '.images-slider-next',
                responsive: [{
                    breakpoint: 768,
                    settings: {
                        dots: true,
                    }
                }],
            });
            $('.breadscrumbs-slider').slick({
                infinite: true,
                speed: 1000,
                arrows: false,
                dots: false,
                variableWidth: true,
            });


            var is_Curr = parseInt($(".breadscrumbs-slider li.sl-current").attr('data-active'));

            if ($(".breadscrumbs-slider").size() != 0) {

                $(".breadscrumbs-slider")[0].slick.slickGoTo(parseInt(is_Curr));

                $(".breadscrumbs-slider").find('li').on('click', function() {
                    var index = $(this).attr('data-slick-index');
                    $(".breadscrumbs-slider").slick('slickGoTo', index);
                });
            }

            setOffSet();

            $(window).resize(function(event) {
                setOffSet();
            });

            function setOffSet() {
                if ($('.banner-nav').size() == 0) return false;



                var _oLeft = $('.banner-nav').offset().left,
                    _oRight = _oLeft + $('.banner-nav').outerWidth() - $(".btn.banner-prev").outerWidth();

                if ($(window).width() < 1261) {
                    _oRight = _oRight - 20;
                    _oLeft = _oLeft + 20;
                }

                $(".btn.banner-prev").css('left', _oLeft);
                $(".btn.banner-next").css('left', _oRight);

                setTimeout(function(argument) {
                    $(".btn.banner-prev").css('opacity', 1);
                    $(".btn.banner-next").css('opacity', 1);
                }, 300);
            }

            setTimeout(function(argument) {
                $(".btn.team-prev").css('opacity', 1);
                $(".btn.team-next").css('opacity', 1);
            }, 300);

        }
    }

    var deviceAgent = navigator.userAgent.toLowerCase();

    var isTouchDevice = Modernizr.touch ||
        (deviceAgent.match(/(iphone|ipod|ipad)/) ||
            deviceAgent.match(/(android)/) ||
            deviceAgent.match(/(iemobile)/) ||
            deviceAgent.match(/iphone/i) ||
            deviceAgent.match(/ipad/i) ||
            deviceAgent.match(/ipod/i) ||
            deviceAgent.match(/blackberry/i) ||
            deviceAgent.match(/bada/i));

    var Jarallax = {
        init: function(argument) {
            $('.jarallax').jarallax({
                speed: 0.2,
                noAndroid: false,
                noIos: false,
            });
        }
    }

    var Form = {
        Valid: function(argument) {
            var _form = $(".form");
            _form.find('input, textarea').focus(function(event) {
                $(this).parent().addClass('on');
            });
            _form.find('input, textarea').blur(function(event) {
                var _value = $(this).val();
                if (_value == "") {
                    $(this).parent().removeClass('on');
                }
            });
        },
        Newsletter: function(argument) {
            var _ele = $("#getnewsletter");

            $(".new-letter .skip").on('click', function(event) {
                event.preventDefault();
                $(".new-letter").find('.form-wrap').removeClass('on-wrap');
                setTimeout(function(argument) {
                    $(".new-letter").removeClass('on');
                }, 450);

                return false;
            });

            _ele.on('click', function(event) {
                event.preventDefault();
                $(".new-letter").addClass('on');
                setTimeout(function(argument) {
                    $(".new-letter").find('.form-wrap').addClass('on-wrap');
                }, 450);


                return false;
            });
            var _close = $(".new-letter").find('.overlay, .icn.icn-close').on('click', function(event) {
                event.preventDefault();
                $(".new-letter").find('.form-wrap').removeClass('on-wrap');
                setTimeout(function(argument) {
                    $(".new-letter").removeClass('on');
                }, 450);

                return false;
            });

        }
    }

    var pltowCol = {
        heightLine: function() {
            $(".intro-content .team-01").heightLine({
                minWidth: 768,
            });
            $(".intro-content .team-02").heightLine({
                minWidth: 768,
            });
            $(".panel-list-two-col .intro-content .title").heightLine({
                minWidth: 768,
            });

            $(".panel.list-testimonial .des").heightLine();
            $(".banner-nav .item").heightLine();

            $(".panel-list-text__horse-services .__logo").heightLine({
                minWidth: 768,
            });
            $(".panel-list-text__horse-services .__des").heightLine({
                minWidth: 768,
            });
        }
    }

    var SelectBox = {
        Switch: function() {
            var _ele = $(".form-select").find('.select-text');
            var _drop = $(".form-select").find('.select-drop');
            var _child = $(".form-select").find('li');
            _ele.on('click', function(event) {
                event.preventDefault();
                var _this = $(this);
                _this.parent().toggleClass('on');
                _this.parent().find('.select-drop').slideToggle(400);
            });
            _child.on('click', function(event) {
                event.preventDefault();
                var _this = $(this);
                var _text = _this.text();
                var _val = _this.attr('data-val');
                _this.parents('.form-select').find('input').attr('value', _val);
                _this.parents('.form-select').find('.select-text').text(_text);
                _this.parents('.form-select').removeClass('on');
                _drop.slideUp(400);
            });
            $('body').on('click', function(event) {
                $dropdowns = $(".form-select");
                $dropdowns.not($dropdowns.has(event.target)).find('.select-drop').slideUp(400);
            });
        }
    }

    var checkBooking = {
        initDate1: function() {
            var daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31],
                today = new Date();
            // set default variable
            setDaysDefault();

            function setDaysDefault() {
                for (var i = 0; i < 31; i++) {
                    if (i < 9) {
                        j = '0';
                    } else {
                        j = '';
                    }
                    $('.select-day ul')
                        .append($("<li></li>")
                            .attr("data-value", i + 1)
                            .text(j + (i + 1)));
                }
            }
            setYears(10); // set the next five years in dropdown
            $(".select-month .selected-month").bind("DOMSubtreeModified", function() {
                monthIndex = $(this).attr('data-value');
                var numIndex = $(this).parents('.select-month').attr('data-verify');
                setDays(monthIndex, numIndex);
            });
            // make sure the number of days correspond with the selected month
            function setDays(monthIndex, numIndex) {
                var __this = $('#select-day' + numIndex);
                var optionCount = __this.find('li').length,
                    daysCount = daysInMonth[monthIndex];
                if (optionCount < daysCount) {
                    for (var i = optionCount; i < daysCount; i++) {
                        if (i < 9) {
                            j = '0';
                        } else {
                            j = '';
                        }
                        __this.find('ul')
                            .append($("<li></li>")
                                .attr("data-value", i + 1)
                                .text(j + (i + 1)));
                    }
                } else {
                    for (var i = daysCount; i < optionCount; i++) {
                        var optionItem = '#select-day' + numIndex + ' li[data-value=' + (i + 1) + ']';
                        $(optionItem).remove();
                    }
                }
            }

            function setYears(val) {
                var year = today.getFullYear();
                for (var i = 0; i < val; i++) {
                    $('.select-year ul')
                        .append($("<li></li>")
                            .attr("data-value", year + i)
                            .text(year + i));
                }
            }
        },
        selectDate: function() {
            $(".form-field").find('span').on('click', function() {
                if ($(this).hasClass('dropped')) {
                    $(this).removeClass('dropped');
                    $(this).parent().find('ul').slideUp();
                } else {
                    $(".form-field").find('span').removeClass('dropped');
                    $(this).addClass('dropped');
                    $(".form-field").find('ul').slideUp();
                    $(this).parent().find('ul').slideDown();
                }
            });
            $(".form-field").find('li').on('click', function() {
                var _attr = $(this).attr('data-value');
                var _this = $(this).parents('.select-box').find('span');
                $(".form-field").find('span').removeClass('dropped');
                $(this).parent('ul').slideUp();
                _this.attr('data-value', _attr)
                _this.html($(this).text());
            });
        }
    }

    var blogTab = {
        init: function() {
            $(".breadscrumbs-full").find('li').on('click', function() {
                if (!$(this).hasClass('active')) {
                    $(".breadscrumbs-full li").removeClass('active');
                    $(this).addClass('active');
                }
            });
        }
    }

    var imgfill = {
        init: function(argument) {
            objectFitImages('picture img');
        }
    }

    var blockLink = {
        Show: function() {
            "use strict";
            $(".__link").click(function() {
                var targ = $(this).find("a").attr("target");
                if (targ === "_blank") {
                    window.open($(this).find("a").attr("href"), '_blank');
                    return false;
                } else {
                    window.location = $(this).find("a").attr("href");
                    return false;
                }
            });
        }
    }

    var blog = {
        init: function() {
            $('a.blog-page.btn-load-more').on('click', function(e) {
                e.preventDefault();
                var self = this;
                $.ajax({
                    url: '',
                    method: 'post',
                    data: {
                        'action': 'crosspark/filter/loadMore',
                        'pageNumber': $(self).attr('data-page'),
                        'blogCat': $(self).attr('data-tab-name')
                    },
                    dataType: 'json',
                    success: function(response) {
                        var currentpage = parseInt($(self).attr('data-page'));
                        $(self).attr('data-page', ++currentpage);

                        if (response.length < 3) $(self).hide();

                        var htmlArr = [];
                        response.forEach(function(item, index) {
                            htmlArr.push('<div class="item">');
                            htmlArr.push('<div class="img">');
                            htmlArr.push('<div class="img-overlay bg" style="background-image: url(' + item.thumbnail.url + ')"></div>');
                            htmlArr.push('</div>');
                            htmlArr.push('<p class="cate">' + item.type + '</p>');
                            htmlArr.push('<p class="title">' + item.title + '</p>');
                            htmlArr.push('<p class="des">' + item.description + '</p>');
                            htmlArr.push('<a class="btn-info" href="' + item.url + '">More info</a>');
                            htmlArr.push('</div>');
                        });
                        var newItemsHtml = htmlArr.join('');
                        $('div.blog-page.list-bot')[0].innerHTML += newItemsHtml;
                    },
                    error: function(error) {
                        console.log(error);
                    }
                });
            })
        }
    }

    var processForm = {
        checkinTop: function() {
            $('#form-checkin-top .form-field__check-available a').on('click', function(event) {
                event.preventDefault();
                var dayCheckin = $('#select-day3 span').attr('data-value');
                var monthCheckin = $('#select-month3 span').attr('data-value');
                var yearCheckin = $('#select-year3 span').attr('data-value');

                var dayCheckout = $('#select-day4 span').attr('data-value');
                var monthCheckout = $('#select-month4 span').attr('data-value');
                var yearCheckout = $('#select-year4 span').attr('data-value');

                var monthCheckinVal = parseInt(monthCheckin) + 1;
                var monthCheckoutVal = parseInt(monthCheckout) + 1;

                var dateCheckinText = monthCheckinVal + '-' + dayCheckin + '-' + yearCheckin;
                var dateCheckoutText = monthCheckoutVal + '-' + dayCheckout + '-' + yearCheckout;
                var dateCheckin = new Date(dateCheckinText);
                var dateCheckout = new Date(dateCheckoutText);

                if (dateCheckin > dateCheckout) {
                    alert('Checkout date must be greater than checkin date');
                } else {
                    var dayCheckinText = $('#select-day3 span').text();
                    var monthCheckinText = $('#select-month3 span').text();
                    var yearCheckinText = $('#select-year3 span').text();
                    var dayCheckoutText = $('#select-day4 span').text();
                    var monthCheckoutText = $('#select-month4 span').text();
                    var yearCheckoutText = $('#select-year4 span').text();

                    var checkinText = dayCheckinText + '/' + monthCheckinText + '/' + yearCheckinText;
                    var checkoutText = dayCheckoutText + '/' + monthCheckoutText + '/' + yearCheckoutText;
                    var mailReceived = $('#mail-received').val();
                    var subjectmailreceived = $('#subjectmailreceived').val();
                    window.location = 'mailto:' + mailReceived + '?subject=' + subjectmailreceived + ' ' + checkinText + ' - ' + checkoutText + ' dates';
                }
            });
        },
        checkinBottom: function() {
            $('#form-checkin-bottom .form-field__check-available a').on('click', function(event) {
                event.preventDefault();
                var dayCheckin = $('#select-day1 span').attr('data-value');
                var monthCheckin = $('#select-month1 span').attr('data-value');
                var yearCheckin = $('#select-year1 span').attr('data-value');

                var dayCheckout = $('#select-day2 span').attr('data-value');
                var monthCheckout = $('#select-month2 span').attr('data-value');
                var yearCheckout = $('#select-year2 span').attr('data-value');

                var monthCheckinVal = parseInt(monthCheckin) + 1;
                var monthCheckoutVal = parseInt(monthCheckout) + 1;

                var dateCheckinText = monthCheckinVal + '-' + dayCheckin + '-' + yearCheckin;
                var dateCheckoutText = monthCheckoutVal + '-' + dayCheckout + '-' + yearCheckout;
                var dateCheckin = new Date(dateCheckinText);
                var dateCheckout = new Date(dateCheckoutText);

                if (dateCheckin > dateCheckout) {
                    alert('Checkout date must be greater than checkin date');
                } else {
                    var dayCheckinText = $('#select-day1 span').text();
                    var monthCheckinText = $('#select-month1 span').text();
                    var yearCheckinText = $('#select-year1 span').text();
                    var dayCheckoutText = $('#select-day2 span').text();
                    var monthCheckoutText = $('#select-month2 span').text();
                    var yearCheckoutText = $('#select-year2 span').text();

                    var checkinText = dayCheckinText + '/' + monthCheckinText + '/' + yearCheckinText;
                    var checkoutText = dayCheckoutText + '/' + monthCheckoutText + '/' + yearCheckoutText;
                    var mailReceived = $('#mail-received').val();
                    var subjectmailreceived = $('#subjectmailreceived').val();
                    window.location = 'mailto:' + mailReceived + '?subject=' + subjectmailreceived + ' ' + checkinText + ' - ' + checkoutText + ' dates';
                }
            });
        }
    }

    var contactForm = {
        getInTouch: function() {
            $("#getInTouch").submit(function(e) {
                var self = this;
                $('#getInTouch button').hide();
                $('#getInTouch .postResult').show();
                e.preventDefault();
                $.ajax({
                    url: '',
                    method: 'post',
                    data: $(self).serialize(),
                    dataType: 'json',
                    success: function(response) {
                        if (response.ok == 'yes') {
                            location.hash = "ok";
                            $('#getInTouch .message').show().html('Thank you for submitting your enquiry. We will be in contact with you shortly.');
                            $('#getInTouch .postResult').hide();
                        } else {
                            $('#getInTouch .message').show().html('Sorry, something went wrong on our server. Please try again later.');
                            $('#getInTouch .postResult').hide();
                            $('#getInTouch button').show();
                        }
                    },
                    error: function(error) {
                        $('#getInTouch .message').show().html('Sorry, something went wrong on our server. Please try again later.');
                        $('#getInTouch .postResult').hide();
                        $('#getInTouch button').show();
                    }
                });
            });
        }
    }

    var videoJS = {
        init: function(argument) {
            var _video = $(".videoPlay"),
                _srTop, _offTop = 0,
                _videoTop;

            if (_video.size() == 0) return false;

            setTimeout(function(argument) {
                _videoTop = _video.offset().top;
                _offTop = _videoTop + ((_video.height() * 3) / 4);
            }, 500);

            playVideoJS();
            $(window).scroll(function(event) {
                playVideoJS();
            });
            var vid = _video.find('video').attr('id');
            function playVideoJS(argument) {
                if (!isTouchDevice) {
                    _srTop = $(window).scrollTop();
                    _sc = $(window).height();
                    if (_offTop != 0) {
                        if ((_srTop + _sc) >= _offTop && _srTop <= _offTop) {
                            videojs(vid).ready(function() {
                                var myPlayer = this;
                                myPlayer.play();
                                _lag = true;
                            });
                        } else {
                            videojs(vid).ready(function() {
                                var myPlayer = this;
                                myPlayer.pause();
                            });
                        }
                    }
                }
            }
        }
    }

    var readAll = {
        click: function() {
            $('.btn-read-all').on('click', function(argument) {
                argument.preventDefault();
                $(this).parents('.des > div').addClass('des-hidden');
                $(this).parents('.des').find('.des-all').removeClass('des-hidden');
            });
        }
    }

    var offerEffect = {
        scroll: function(argument) {
            $(window).scroll(function(event) {
                $('.panel-offer__item').find('.content').each(function() {
                    var ofst = $(this).offset().top;
                    var wsct = $(window).scrollTop();
                    if (wsct > (ofst - ($(window).height() - 50))) {
                        var _pos = parseInt((wsct - (ofst - ($(window).height() - 50))) / 10);
                        if (_pos > 0) {
                            $(this).css({
                                transform: 'matrix(1, 0, 0, 1, 0, ' + _pos + ')'
                            });
                        }
                    } else {
                        $(this).css({
                            transform: 'matrix(1, 0, 0, 1, 0, 0)'
                        });
                    }
                });
            });
        }
    }

    jQuery(document).ready(function($) {
        $("img.lazy").show().lazyload({
            threshold: 200
        });
        $("div.lazy").show().lazyload({
            threshold: 200
        });

        new WOW().init();
        videoJS.init();
        Header.navSub();
        Header.Hover();
        imgfill.init();
        Jarallax.init();
        Header.Scroll();
        Header.toggleButton();
        Slider.initSlider();
        Form.Valid();
        Form.Newsletter();
        pltowCol.heightLine();
        SelectBox.Switch();
        checkBooking.initDate1();
        checkBooking.selectDate();
        blogTab.init();
        blockLink.Show();
        blog.init();
        processForm.checkinTop();
        processForm.checkinBottom();
        contactForm.getInTouch();
        readAll.click();
        //offerEffect.scroll();
    });

})(window, document);
(function($) {
    var scrollbarWidth = 0,
        originalMargin, touchHandler = function(event) {
            event.preventDefault();
        };

    function getScrollbarWidth() {
        if (scrollbarWidth) return scrollbarWidth;
        var scrollDiv = document.createElement('div');
        $.each({
            top: '-9999px',
            width: '50px',
            height: '50px',
            overflow: 'scroll',
            position: 'absolute'
        }, function(property, value) {
            scrollDiv.style[property] = value;
        });
        $('body').append(scrollDiv);
        scrollbarWidth = scrollDiv.offsetWidth - scrollDiv.clientWidth;
        $('body')[0].removeChild(scrollDiv);
        return scrollbarWidth;
    }
})(jQuery);
