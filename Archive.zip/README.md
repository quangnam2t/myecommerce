# Cross Park website

## Overview

* Technology: Craft 2.6, Grunt

## Deploying
* Dev
> git remote add staging root@188.166.211.207:/var/www/html/crosspark.stage.intersquad.co.git
> git push staging stage

# CHANGE LOG
Add a change log entry when changes are pushed live, put items under headings `Added`, `Changed`, `Fixed` or `Unreleased`

###Added
  * Initial setup

## Guide
* To run this project
> 1. Install nodejs: https://nodejs.org/en/download/
> 2. Install sass: http://sass-lang.com/install
> 3. Install grunt-cli: npm install grunt-cli -g
> 4. Open cmd at root project (same directory with package.json) then run: npm install
> 5. After node modules are installed successful, then run: grunt dev
> 6. Files are served at http://localhost:3000/static/home.html (i created a file named home.html)

* To start html development
> 1. Css: create scss files in css folder, then import into all.scss.
> 2. Js: write code in js/app.js. Put js libraries in /js/vendor/.
> 3. Fonts: put all font files in fonts folder.
> 4. Images: put all images in images folder.
> 5. Html: we use twig for templates. Put html files into html folder.
