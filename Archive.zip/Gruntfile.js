module.exports = function (grunt) {
    var getUniqueId = function() {
        return new Date().getTime();
    }

    // Project configuration.
    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),
        //watch
        watch: {
            sass: {
                files: ['css/**/*.scss'],
                tasks: ['sass', 'regex-replace:cachebustcss']
            },
            copy: {
                files: ['fonts/**/*.*'],
                tasks: ['copy']
            },
            imagemin: {
                files: ['images/**/*'],
                tasks: ['imagemin']
            },
            js: {
                files: ['js/**/*.js'],
                tasks: ['concat', 'uglify', 'regex-replace:cachebustjs'],
                options: {
                    spawn: false
                }
            },
            output_twig: {
                files: ['html/_static/**/*.html'],
                tasks: ['output_twig']
            }
        },
        //sass
        sass: {
            dev: {
                files: {
                    'public/css/all.css': ['css/all.scss']
                }
            },
            build: {
                options: {
                    style: 'compressed',
                    // sourcemap: 'none'
                },
                files: {
                    'public/css/all.css': ['css/all.scss']
                }
            }
        },

        concat: {
            vendor: {
                src: [
                    'js/vendor/jquery-2.1.1.js',
                    'js/vendor/imageloader.js',
                    'js/vendor/modernizr-v2.8.3.js',
                    'js/vendor/smoothscroll.js',
                    'js/vendor/jquery.lazyload.min.js',
                    'js/vendor/jquery.hoverIntent.js',
                    'js/vendor/ofi.min.js',
                    'js/vendor/slick.js',
                    'js/vendor/heightLine.js',
                    'js/vendor/Jarallax.js',
                    'js/vendor/wow.js',
                    'js/vendor/video.js',
                    'js/vendor/youtube.min.js',
                ],
                dest: 'public/js/vendor.js'
            },
            app: {
                src: [
                    'js/app.js'
                ],
                dest: 'public/js/all.js'
            }
        },
        connect: {
            server: {
                options: {
                    port: 3000,
                    protocol: "http",
                    hostname: "localhost",
                    base: 'public',
                    directory: 'static',
                    livereload: true
                }
            }
        },
        uglify: {
            vendor: {
                src: [
                    'js/vendor/jquery-2.1.1.js',
                    'js/vendor/imageloader.js',
                    'js/vendor/modernizr-v2.8.3.js',
                    'js/vendor/smoothscroll.js',
                    'js/vendor/jquery.lazyload.min.js',
                    'js/vendor/jquery.hoverIntent.js',
                    'js/vendor/ofi.min.js',
                    'js/vendor/slick.js',
                    'js/vendor/heightLine.js',
                    'js/vendor/Jarallax.js',
                    'js/vendor/wow.js',
                    'js/vendor/video.js',
                    'js/vendor/youtube.min.js',
                ],
                dest: 'public/js/vendor.js'
            },
            app: {
                src: [
                    'js/app.js'
                ],
                dest: 'public/js/all.js'
            }
        },
        copy: {
            pie: {
                src: 'css/PIE.htc',
                dest: 'public/css/PIE.htc'
            },
            font: {
                expand: true,
                src: ['fonts/**/*'],
                dest: 'public/',
                filter: 'isFile'
            }
        },
        output_twig: {
            options: {
                docroot: 'html/_static/'
            },
            files: {
                expand: true,
                cwd: 'html/_static/',
                src: ['*.html'],
                dest: 'public/static/',
                ext: '.html'
            },
        },
        imagemin: {
            dynamic: {
                files: [{
                    expand: true,
                    cwd: 'images/',
                    src: ['**/*.*'],
                    dest: 'public/images/'
                }]
            }
        },
        'regex-replace': {
            cachebustcss: {
                src: [
                    'html/_static/_includes/foot.html',
                    'html/_static/_includes/head.html',
                    'html/_craft/_includes/head.html',
                    'html/_craft/_includes/foot.html'
                ],
                actions: [
                    {
                        search: /(.css\?v=)\d+?(")/g,
                        replace: '$1' + getUniqueId() + '$2'
                    }
                ]
            },
            cachebustjs: {
                src: [
                    'html/_static/_includes/foot.html',
                    'html/_static/_includes/head.html',
                    'html/_craft/_includes/head.html',
                    'html/_craft/_includes/foot.html'
                ],
                actions: [
                    {
                        search: /(.js\?v=)\d+?(")/g,
                        replace: '$1' + getUniqueId() + '$2'
                    }
                ]
            },
        }

    });
    //Load the plugin
    grunt.loadNpmTasks('grunt-contrib-connect');
    grunt.loadNpmTasks('grunt-contrib-watch');
    grunt.loadNpmTasks('grunt-contrib-sass');
    grunt.loadNpmTasks('grunt-contrib-concat');
    grunt.loadNpmTasks('grunt-contrib-uglify');
    grunt.loadNpmTasks('grunt-contrib-copy');
    grunt.loadNpmTasks('grunt-output-twig');
    grunt.loadNpmTasks('grunt-contrib-imagemin');
    grunt.loadNpmTasks('grunt-regex-replace');
    // Default task(s).
    grunt.registerTask('build', ['sass:build', 'concat', 'uglify', 'copy', 'imagemin', 'regex-replace', 'output_twig']);
    grunt.registerTask('dev', ['sass:dev','concat', 'uglify', 'copy', 'imagemin', 'regex-replace', 'output_twig', 'connect', 'watch']);
};