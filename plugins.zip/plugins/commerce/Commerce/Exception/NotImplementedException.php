<?php

namespace Commerce\Exception;

class NotImplementedException extends \BadMethodCallException
{}