<?php
namespace Commerce\Gateways\Omnipay;

class FirstData_Connect_GatewayAdapter extends \Commerce\Gateways\OffsiteGatewayAdapter
{
    public function handle()
    {
        return 'FirstData_Connect';
    }
}