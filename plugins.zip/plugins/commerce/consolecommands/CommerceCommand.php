<?php
namespace Craft;

class CommerceCommand extends BaseCommand
{
    public function actionIndex()
    {
        //TODO Expose some tasks to command line
        return true;
    }
}