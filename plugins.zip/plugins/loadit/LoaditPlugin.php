<?php
namespace Craft;

class LoaditPlugin extends BasePlugin
{
    public function getName()
    {
        return 'Loadit';
    }

	function getVersion()
	{
		return '0.1';
	}

	function getDeveloper()
	{
		return 'Intersquad Team';
	}

	function getDeveloperUrl()
	{
		return 'http://intersquad.co/';
	}

	function registerSiteRoutes()
	{
		return array('loadit/load/loaditems' => array('action' => 'loadit/load/loaditems'));
	}
}
