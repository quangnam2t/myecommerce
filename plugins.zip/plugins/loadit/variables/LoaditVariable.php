<?php
namespace Craft;

class LoaditVariable
{
    public function LoadItems($number_of_items, $offset)
    {
        $criteria          = craft()->elements->getCriteria(ElementType::Entry);
        $criteria->section = 'newsEvents';
        $criteria->limit   = $number_of_items;
        $criteria->offset  = $offset;

        $entries = $criteria->find();

        echo count($entries, COUNT_RECURSIVE);

        $result = [];

        foreach ($entries as $ent) {
            # code...
            array_push($result, $ent);
        }

        return $result;
    }
}
