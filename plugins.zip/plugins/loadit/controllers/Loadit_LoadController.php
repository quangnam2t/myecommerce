<?php
namespace Craft;

class Loadit_LoadController extends BaseController
{
    protected $allowAnonymous = array('actionLoadItems');

    public function actionLoadItems()
    {
        $this->requirePostRequest();
        try {
            $page          = (int) craft()->request->getPost('pageNumber');
            $default_items = (int) craft()->request->getPost('itemCount');
            //$default_items =1;

        } catch (Exception $e) {
            $this->returnJson('Cannot parse to interger');
        }

        $entryType = craft()->request->getPost('entryType');
        $criteria          = craft()->elements->getCriteria(ElementType::Entry);
        $criteria->section = $entryType;
        $criteria->limit   = $default_items == -1 ? null : $default_items;
        $criteria->offset  = $default_items * $page;
        $criteria->order   = array('postDate desc');

        $entries = craft()->elements->findElements($criteria, false);

        $items = array();
            $results = [];
            if(count($entries)){
                foreach ($entries as $ent) {
                    $temp = new \stdClass();
                    $temp->title = $ent->title;
                    $temp->url = $ent->url;
                    $temp->location = $ent->ne_location;
                    $temp->img = new \stdClass();
                    $temp->img->url = $ent->ne_image->first()->url;
                    if($ent->ne_date){
                        $date = date_create($ent->ne_date);
                        $temp->postDate = date_format($date, 'd-M-Y');
                    }else{
                        $date = date_create($ent->ne_date);
                        $temp->postDate = date_format($date, 'd-M-Y');
                    }
                    $temp->cate = array();
                    foreach ($ent->ne_type as $cate) {
                        $cate_tmp = new \stdClass();
                        $cate_tmp->id = $cate->id;
                        $cate_tmp->title = $cate->title;
                        $cate_tmp->showdate = $cate->showDate;
                        array_push($temp->cate, $cate_tmp);
                    }
                    $items['items'][] = $temp;
                }
            }else{
                $items['items'] = '';
            }
            $results = array_merge($results,$items);





        return $this->returnJson($results);
    }
}
